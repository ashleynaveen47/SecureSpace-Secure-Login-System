# SecureSpace — Secure Login System

A responsive login/register application built with **Python Flask, SQLite, HTML and CSS**.

## Features
- Register, log in, dashboard and log out
- SQLite database integration
- Password hashing using Werkzeug (passwords are never stored as plain text)
- Parameterized SQL queries
- CSRF protection on forms
- Login/register rate limiting
- Session timeout and HTTP-only / SameSite cookies
- Basic security response headers
- Responsive layout for desktop and mobile

## Run locally (Windows / VS Code)

1. Install Python 3.
2. Open this project folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:

   ```powershell
   py -m venv venv
   .\venv\Scripts\activate
   ```

5. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

6. Set a secret key for your local session:

   ```powershell
   $env:SECRET_KEY = "replace-this-with-a-long-random-secret"
   ```

7. Start the application:

   ```powershell
   python app.py
   ```

8. Open `http://127.0.0.1:5000` in your browser and create an account.

The SQLite database file `users.db` is created automatically on first run.

## Project structure

```text
secure_login_system/
│── app.py
│── requirements.txt
│── README.md
│── users.db             # created automatically
│
├── templates/
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   └── dashboard.html
│
└── static/
    └── style.css
```

## Security notes
- The default secret key is for local development only. Always set a strong random `SECRET_KEY`.
- For HTTPS deployment, set `COOKIE_SECURE=1` so the browser sends the session cookie only over HTTPS.
- Set `debug=False` in production and use a production WSGI server.
- This is an educational starter project, not a complete production identity platform. Production systems should also include email verification, password reset, stronger password policy, monitoring, backups and HTTPS.
